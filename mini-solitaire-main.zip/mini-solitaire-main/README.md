# mini-solitaire
A klondlike solitaire "demake" made withPyxel.
